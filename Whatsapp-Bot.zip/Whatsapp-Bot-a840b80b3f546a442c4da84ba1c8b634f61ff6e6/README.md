 
## Yo Minna san Konichiwa <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/hmm.gif" width="29px"> ???
<img align="center" height="auto" src="https://i.ytimg.com/vi/rHmqby4MRdo/maxresdefault.jpg"/>

___

### For Termux
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> git clone https://github.com/mamet8/Whatsapp-Bot
> cd Whatsapp-Bot
> npm i
```

### Run
```
> npm start
```

___

### For VPS
```bash
> npm i
```

### Run
```bash
> npm start
```

## Special Thanks to
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`Zhoe`](https://github.com/chalyyzhu)
* [`Ryns`](https://github.com/rynkings)
